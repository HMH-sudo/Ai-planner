create table if not exists public.maintenance_tasks (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  title text not null,
  category text default 'PM',
  priority text default 'Medium',
  status text default 'Open',
  owner text default 'Hussain',
  due_date date,
  notes text default '',
  approval_required boolean default true,
  archived boolean default false
);

alter table public.maintenance_tasks enable row level security;

drop policy if exists "Enable all for authenticated users" on public.maintenance_tasks;
create policy "Enable all for authenticated users"
on public.maintenance_tasks
for all
using (auth.role() = 'authenticated')
with check (auth.role() = 'authenticated');

create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists set_tasks_updated_at on public.maintenance_tasks;
create trigger set_tasks_updated_at
before update on public.maintenance_tasks
for each row execute function public.set_updated_at();

alter publication supabase_realtime add table public.maintenance_tasks;
