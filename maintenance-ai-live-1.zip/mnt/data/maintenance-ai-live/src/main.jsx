import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle2, Clock, Download, Mail, Plus, Search, ShieldCheck, Trash2, Wrench, LogOut, Bot, RefreshCw } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import './styles.css';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabaseReady = Boolean(supabaseUrl && supabaseKey && !supabaseUrl.includes('your_'));
const supabase = supabaseReady ? createClient(supabaseUrl, supabaseKey) : null;

const categories = ['PR', 'PO', 'WO', 'GR', 'PM', 'HSE', 'Vendor', 'Spare Parts', 'Email', 'Other'];
const priorities = ['Low', 'Medium', 'High', 'Critical'];
const statuses = ['Open', 'In Progress', 'Waiting Vendor', 'Waiting Approval', 'Need Decision', 'Completed', 'Delayed'];

const demoTasks = [
  { id: 'demo-1', title: 'Follow up PO #96007859 ETA', category: 'PO', priority: 'High', status: 'Waiting Vendor', owner: 'Vendor', due_date: '2026-05-10', notes: 'Ask vendor for delivery status and ETA.', approval_required: true, archived: false },
  { id: 'demo-2', title: 'Prepare GR list for invoice #3', category: 'GR', priority: 'Medium', status: 'Completed', owner: 'Hussain', due_date: '2026-05-09', notes: 'GR numbers ready for sharing.', approval_required: false, archived: false },
  { id: 'demo-3', title: 'Close HSE observations with evidence photos', category: 'HSE', priority: 'High', status: 'Need Decision', owner: 'Team', due_date: '2026-05-09', notes: 'Need confirmation from all TLs.', approval_required: true, archived: false },
  { id: 'demo-4', title: 'Update Digital PM Checklist export format', category: 'PM', priority: 'Medium', status: 'In Progress', owner: 'Hussain', due_date: '2026-05-12', notes: 'Horizontal Excel export, delete, archive, print PDF fix.', approval_required: false, archived: false },
];

function todayISO() { return new Date().toISOString().slice(0, 10); }

function Badge({ children, type }) { return <span className={`badge ${type || ''}`}>{children}</span>; }
function Field({ label, children }) { return <label><span>{label}</span>{children}</label>; }
function Card({ children, className = '' }) { return <div className={`card ${className}`}>{children}</div>; }

function Login({ onLogin }) {
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');
  async function signIn() {
    if (!supabaseReady) { setMsg('Supabase غير مربوط حالياً. النظام يعمل Demo Mode.'); return; }
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: window.location.origin } });
    setMsg(error ? error.message : 'تم إرسال رابط الدخول على بريدك.');
  }
  return <div className="login-page"><Card className="login-card"><h1>Maintenance Planner AI</h1><p>Live dashboard لمتابعة مهام الصيانة من أي مكان.</p><input placeholder="Your email" value={email} onChange={e=>setEmail(e.target.value)} /><button onClick={signIn}>Send Login Link</button><button className="secondary" onClick={onLogin}>Continue Demo Mode</button>{msg && <p className="small">{msg}</p>}</Card></div>;
}

function Stat({ title, value, icon: Icon, hint }) { return <Card className="stat"><div className="icon"><Icon size={24}/></div><div><p>{title}</p><h2>{value}</h2>{hint && <small>{hint}</small>}</div></Card>; }

function App() {
  const [session, setSession] = useState(null);
  const [demo, setDemo] = useState(!supabaseReady);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(false);
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [aiInput, setAiInput] = useState('');
  const [aiOutput, setAiOutput] = useState('');
  const [draft, setDraft] = useState({ title: '', category: 'PM', priority: 'Medium', status: 'Open', owner: 'Hussain', due_date: todayISO(), notes: '', approval_required: true, archived: false });

  useEffect(() => {
    if (!supabaseReady) { setTasks(JSON.parse(localStorage.getItem('demo_tasks') || 'null') || demoTasks); return; }
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, newSession) => setSession(newSession));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (demo) { localStorage.setItem('demo_tasks', JSON.stringify(tasks)); return; }
    if (!session || !supabaseReady) return;
    loadTasks();
    const channel = supabase.channel('maintenance_tasks_live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'maintenance_tasks' }, loadTasks)
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [session, demo]);

  async function loadTasks() {
    if (!supabaseReady || demo) return;
    setLoading(true);
    const { data, error } = await supabase.from('maintenance_tasks').select('*').order('created_at', { ascending: false });
    if (!error) setTasks(data || []);
    setLoading(false);
  }

  async function addTask() {
    if (!draft.title.trim()) return;
    if (demo) { setTasks([{ ...draft, id: crypto.randomUUID() }, ...tasks]); setDraft({ ...draft, title: '', notes: '' }); return; }
    await supabase.from('maintenance_tasks').insert(draft);
    setDraft({ ...draft, title: '', notes: '' });
  }

  async function updateTask(id, patch) {
    if (demo) { setTasks(tasks.map(t => t.id === id ? { ...t, ...patch } : t)); return; }
    await supabase.from('maintenance_tasks').update(patch).eq('id', id);
  }

  async function deleteTask(id) {
    if (demo) { setTasks(tasks.filter(t => t.id !== id)); return; }
    await supabase.from('maintenance_tasks').delete().eq('id', id);
  }

  const active = tasks.filter(t => !t.archived);
  const filtered = active.filter(t => (`${t.title} ${t.category} ${t.status} ${t.priority} ${t.owner} ${t.notes}`).toLowerCase().includes(query.toLowerCase()) && (statusFilter === 'All' || t.status === statusFilter) && (priorityFilter === 'All' || t.priority === priorityFilter));
  const delayed = active.filter(t => t.status === 'Delayed' || (t.due_date && t.due_date < todayISO() && t.status !== 'Completed'));
  const needDecision = active.filter(t => t.status === 'Need Decision' || t.approval_required);
  const completed = active.filter(t => t.status === 'Completed');
  const critical = active.filter(t => t.priority === 'Critical');
  const statusChart = statuses.map(s => ({ name: s, count: active.filter(t => t.status === s).length })).filter(x => x.count);
  const categoryChart = categories.map(c => ({ name: c, count: active.filter(t => t.category === c).length })).filter(x => x.count);

  function exportCSV() {
    const headers = ['Title','Category','Priority','Status','Owner','Due Date','Approval Required','Notes'];
    const rows = active.map(t => [t.title,t.category,t.priority,t.status,t.owner,t.due_date,t.approval_required?'Yes':'No',t.notes]);
    const csv = [headers,...rows].map(r => r.map(c => `"${String(c || '').replaceAll('"','""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `maintenance_tasks_${todayISO()}.csv`; a.click(); URL.revokeObjectURL(url);
  }

  function generateAiDraft() {
    const urgent = active.filter(t => ['Critical','High'].includes(t.priority) && t.status !== 'Completed');
    const lines = urgent.map(t => `- ${t.title} | ${t.category} | ${t.priority} | ${t.status} | Due: ${t.due_date || 'N/A'}`).join('\n');
    setAiOutput(`Daily Maintenance Summary\n\nCompleted:\n${completed.map(t=>'✓ '+t.title).join('\n') || '- None'}\n\nDelayed:\n${delayed.map(t=>'⚠ '+t.title + ' - Due ' + t.due_date).join('\n') || '- None'}\n\nNeed Decision / Approval:\n${needDecision.map(t=>'• '+t.title).join('\n') || '- None'}\n\nCritical / High Priority:\n${lines || '- None'}\n\nSuggested Action:\n${aiInput || 'Please review the pending approvals and vendor follow-ups before sending any email or updating official records.'}`);
  }

  if (!session && !demo) return <Login onLogin={() => { setDemo(true); setTasks(demoTasks); }} />;

  return <div className="app"><motion.header initial={{opacity:0,y:-10}} animate={{opacity:1,y:0}}><div><h1>Maintenance Planner AI Dashboard</h1><p>{demo ? 'Demo Mode - اربط Supabase ليعمل لايف من أي مكان' : 'Live Mode - البيانات متزامنة لحظياً'}</p></div><div className="actions"><button onClick={loadTasks}><RefreshCw size={16}/>Refresh</button><button onClick={exportCSV}><Download size={16}/>Export CSV</button>{session && <button onClick={()=>supabase.auth.signOut()}><LogOut size={16}/>Logout</button>}</div></motion.header>

  <section className="stats"><Stat title="Active Tasks" value={active.length} icon={Wrench}/><Stat title="Completed" value={completed.length} icon={CheckCircle2}/><Stat title="Delayed" value={delayed.length} icon={AlertTriangle}/><Stat title="Need Decision" value={needDecision.length} icon={ShieldCheck}/><Stat title="Critical" value={critical.length} icon={Clock}/></section>

  <section className="grid"><Card className="wide"><h2>Add New Task</h2><div className="form-grid"><Field label="Title"><input value={draft.title} onChange={e=>setDraft({...draft,title:e.target.value})}/></Field><Field label="Category"><select value={draft.category} onChange={e=>setDraft({...draft,category:e.target.value})}>{categories.map(x=><option key={x}>{x}</option>)}</select></Field><Field label="Priority"><select value={draft.priority} onChange={e=>setDraft({...draft,priority:e.target.value})}>{priorities.map(x=><option key={x}>{x}</option>)}</select></Field><Field label="Status"><select value={draft.status} onChange={e=>setDraft({...draft,status:e.target.value})}>{statuses.map(x=><option key={x}>{x}</option>)}</select></Field><Field label="Due Date"><input type="date" value={draft.due_date} onChange={e=>setDraft({...draft,due_date:e.target.value})}/></Field><Field label="Owner"><input value={draft.owner} onChange={e=>setDraft({...draft,owner:e.target.value})}/></Field></div><textarea placeholder="Notes / next action" value={draft.notes} onChange={e=>setDraft({...draft,notes:e.target.value})}/><label className="check"><input type="checkbox" checked={draft.approval_required} onChange={e=>setDraft({...draft,approval_required:e.target.checked})}/> Requires my approval</label><button onClick={addTask}><Plus size={16}/>Add Task</button></Card>

  <Card><h2><Bot size={20}/> AI Draft Assistant</h2><textarea placeholder="اكتب المطلوب من المساعد، مثال: جهز لي follow-up للموردين المتأخرين" value={aiInput} onChange={e=>setAiInput(e.target.value)}/><button onClick={generateAiDraft}><Mail size={16}/>Generate Draft / Summary</button>{aiOutput && <pre className="ai-output">{aiOutput}</pre>}</Card></section>

  <section className="filters"><div className="search"><Search size={16}/><input placeholder="Search tasks..." value={query} onChange={e=>setQuery(e.target.value)}/></div><select value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}><option>All</option>{statuses.map(x=><option key={x}>{x}</option>)}</select><select value={priorityFilter} onChange={e=>setPriorityFilter(e.target.value)}><option>All</option>{priorities.map(x=><option key={x}>{x}</option>)}</select></section>

  <section className="task-list">{loading && <p>Loading...</p>}{filtered.map(t => <Card key={t.id} className="task"><div className="task-head"><input className="task-title" value={t.title} onChange={e=>updateTask(t.id,{title:e.target.value})}/><div><Badge type={t.status.replaceAll(' ','-').toLowerCase()}>{t.status}</Badge><Badge type={t.priority.toLowerCase()}>{t.priority}</Badge>{t.approval_required && <Badge type="approval">Approval</Badge>}</div></div><div className="task-grid"><select value={t.category} onChange={e=>updateTask(t.id,{category:e.target.value})}>{categories.map(x=><option key={x}>{x}</option>)}</select><select value={t.priority} onChange={e=>updateTask(t.id,{priority:e.target.value})}>{priorities.map(x=><option key={x}>{x}</option>)}</select><select value={t.status} onChange={e=>updateTask(t.id,{status:e.target.value})}>{statuses.map(x=><option key={x}>{x}</option>)}</select><input type="date" value={t.due_date || ''} onChange={e=>updateTask(t.id,{due_date:e.target.value})}/><input value={t.owner || ''} onChange={e=>updateTask(t.id,{owner:e.target.value})}/></div><textarea value={t.notes || ''} onChange={e=>updateTask(t.id,{notes:e.target.value})}/><div className="task-actions"><button className="secondary" onClick={()=>updateTask(t.id,{archived:true})}>Archive</button><button className="danger" onClick={()=>deleteTask(t.id)}><Trash2 size={16}/>Delete</button></div></Card>)}</section>

  <section className="grid charts"><Card><h2>Tasks by Status</h2><ResponsiveContainer width="100%" height={260}><BarChart data={statusChart}><XAxis dataKey="name" tick={{fontSize:10}}/><YAxis allowDecimals={false}/><Tooltip/><Bar dataKey="count" radius={[8,8,0,0]}/></BarChart></ResponsiveContainer></Card><Card><h2>Tasks by Category</h2><ResponsiveContainer width="100%" height={260}><PieChart><Pie data={categoryChart} dataKey="count" nameKey="name" outerRadius={90} label>{categoryChart.map((_,i)=><Cell key={i}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer></Card></section>
  </div>;
}

createRoot(document.getElementById('root')).render(<App />);
