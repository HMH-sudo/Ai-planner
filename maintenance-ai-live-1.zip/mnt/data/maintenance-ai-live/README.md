# Maintenance Planner AI Live Dashboard

نظام MVP لايف لمتابعة مهام Maintenance Planner من الجوال والكمبيوتر.

## المميزات
- Dashboard تفاعلي Live.
- Supabase Database + Realtime.
- Login بالبريد عبر Supabase Magic Link.
- إضافة / تعديل / أرشفة / حذف المهام.
- تصنيف PR / PO / WO / GR / PM / HSE / Vendor / Spare Parts.
- Daily Summary: Completed / Delayed / Need Decision.
- Export CSV.
- AI Draft Assistant داخلي يجهز نصوص متابعة وتقارير بدون إرسال أي شيء.

## التشغيل محليًا
```bash
npm install
cp .env.example .env
npm run dev
```

## ربط Supabase
1. افتح Supabase وأنشئ Project.
2. من SQL Editor شغل ملف `supabase_schema.sql`.
3. من Project Settings > API انسخ:
   - Project URL
   - anon public key
4. ضعها في `.env`:
```bash
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
```
5. شغل المشروع.

## النشر على Vercel
1. ارفع المشروع على GitHub.
2. اربطه مع Vercel.
3. أضف Environment Variables نفسها.
4. Deploy.

## ملاحظة مهمة
ربط Gmail/Outlook يتم في المرحلة الثانية عبر Backend آمن، وليس مباشرة من المتصفح.
